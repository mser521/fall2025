const numbers = [3, 8, 12, 5, 19, 21, 4, 10, 7, 16];
const fruits = ['apple', 'banana', 'cherry', 'date', 'grape', 'kiwi', 'lemon', 'mango', 'orange'];

// 1. Print the first number in the list to the console.
console.log('1. Print the first number in the list to the console.');

// 2. Print the second number in the list to the console.
console.log('2. Print the second number in the list to the console.');

// 3. Print the third number in the list to the console.
console.log('3. Print the third number in the list to the console.');

// 4. Print the last number in the list to the console.
console.log('4. Print the last number in the list to the console.');

// 5. Using a "for...of loop", print each number to the console.
console.log('5. Using a "for...of loop", print each number to the console.');
